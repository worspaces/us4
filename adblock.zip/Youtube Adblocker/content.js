(function() {
  const showButton = false;
  const button = document.createElement("button");
  button.innerText = "Manually Skip Ad";
  button.style.position = "fixed";
  button.style.bottom = "20px";
  button.style.right = "20px";
  button.style.padding = "12px 24px";
  button.style.border = "none";
  button.style.borderRadius = "8px";
  button.style.fontSize = "16px";
  button.style.cursor = "pointer";
  button.style.zIndex = "9999";
  button.style.transition = "all 0.3s ease-in-out";
  button.style.boxShadow = "0 4px 10px rgba(0, 0, 0, 0.2)";
  button.style.fontFamily = "Arial, sans-serif";

  const isDarkMode = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  button.style.backgroundColor = isDarkMode ? "#333" : "#FFF";
  button.style.color = isDarkMode ? "#FFF" : "#000";
  button.onmouseover = () => {
    button.style.backgroundColor = isDarkMode ? "#555" : "#f1f1f1";
  };
  button.onmouseout = () => {
    button.style.backgroundColor = isDarkMode ? "#333" : "#FFF";
  };

  function skipAd() {
    const videoAds = document.querySelector(".video-ads");
    if (videoAds && videoAds.innerHTML !== "") {
      let banner = false;
      document.querySelectorAll(".ytp-ad-overlay-close-button").forEach(button => {
        button.click();
        banner = true;
      });
      if (!banner) {
        const video = document.querySelector(".html5-main-video");
        if (video) {
          video.currentTime = video.duration;
        }
        const skipButton = document.querySelector(".ytp-ad-skip-button, .ytp-ad-skip-button-modern");
        if (skipButton) {
          skipButton.click();
        }
      }
    }
  }

  if (showButton) {
    button.onclick = skipAd;
    document.body.appendChild(button);
  }

  function createNotification(message) {
    const notification = document.createElement('div');
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.backgroundColor = '#222';
    notification.style.color = 'gold';
    notification.style.padding = '15px 20px';
    notification.style.borderRadius = '5px';
    notification.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.2)';
    notification.style.fontFamily = 'Arial, sans-serif';
    notification.style.fontSize = '16px';
    notification.style.zIndex = '9999';
    notification.style.display = 'flex';
    notification.style.justifyContent = 'space-between';
    notification.style.alignItems = 'center';

    const messageSpan = document.createElement('span');
    messageSpan.textContent = message;
    notification.appendChild(messageSpan);

    const closeButton = document.createElement('button');
    closeButton.textContent = 'X';
    closeButton.style.backgroundColor = 'transparent';
    closeButton.style.color = 'gold';
    closeButton.style.border = 'none';
    closeButton.style.cursor = 'pointer';
    closeButton.style.marginLeft = '10px';
    closeButton.style.fontSize = '16px';
    closeButton.style.fontWeight = 'bold';
    closeButton.addEventListener('click', () => {
      document.body.removeChild(notification);
    });

    notification.appendChild(closeButton);

    const topBar = document.createElement('div');
    topBar.style.position = 'absolute';
    topBar.style.top = '0';
    topBar.style.left = '0';
    topBar.style.height = '4px';
    topBar.style.backgroundColor = 'gold';
    topBar.style.width = '100%';
    topBar.style.transition = 'width 5s linear';
    notification.appendChild(topBar);

    document.body.appendChild(notification);
    setTimeout(() => {
      topBar.style.width = '0';
    }, 50);
    setTimeout(() => {
      if (document.body.contains(notification)) {
        document.body.removeChild(notification);
      }
    }, 5050);
  }

  createNotification("Ad Blocker Loaded");

  setInterval(function() {
    skipAd();
    document.querySelectorAll('img.ytwAdImageViewModelHostImage.yt-core-image--fill-parent-height.yt-core-image--fill-parent-width.yt-core-image--content-mode-scale-aspect-fit.yt-core-image--loaded')
      .forEach(img => {
        img.src = "https://i.ibb.co/VcRbwSnL/download.png";
      });

    document.querySelectorAll('.ytwFeedAdMetadataViewModelHostMetadata, .ytwAdButtonViewModelHost.ytwSquareImageLayoutViewModelHostMetadataButtonContainerButton, .ad-inline-playback-metadata, .ytwAdAvatarLockupViewModelHostTextsStyleCompact, .style-scope.ytd-promoted-video-renderer, .style-scope.ytd-in-feed-ad-layout-renderer')
      .forEach(element => {
        element.remove();
      });

    document.querySelectorAll('[class*="style-scope ytd-ad-inline-playback-meta-block"]')
      .forEach(element => {
        element.remove();
      });

    const clickableAdComponent = document.querySelector(".ytwAdImageViewModelHostIsClickableAdComponent");
    if (clickableAdComponent) {
      let parent1 = clickableAdComponent.parentElement;
      let parent2 = parent1 ? parent1.parentElement : null;

      if (parent2) {
        parent2.remove();
      }
      if (parent1) {
        parent1.remove();
      }
    }

    document.querySelectorAll('.masthead-ad')
      .forEach(ad => {
        ad.remove();
      });
  }, 100);
})();
